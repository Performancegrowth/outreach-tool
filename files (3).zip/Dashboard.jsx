import { useState, useEffect } from "react";

const API = process.env.REACT_APP_API_URL || "http://localhost:3000/api";

// ─── DESIGN TOKENS ────────────────────────────────────────────────────────────
const C = {
  bg: "#07090f",
  surface: "#0f1218",
  card: "#131920",
  border: "rgba(255,255,255,0.06)",
  borderHover: "rgba(255,255,255,0.12)",
  brand: "#3b82f6",
  brandDim: "#1d4ed8",
  green: "#22c55e",
  yellow: "#f59e0b",
  red: "#ef4444",
  purple: "#8b5cf6",
  cyan: "#06b6d4",
  muted: "#4b5563",
  dim: "#6b7280",
  sub: "#9ca3af",
  text: "#e2e8f0",
  white: "#f8fafc",
};

const STATUS_C = {
  cold: C.muted,
  review_queue: C.yellow,
  messaged: C.brand,
  replied: C.purple,
  interested: C.green,
  booked: C.cyan,
  closed: "#10b981",
  rejected: C.red,
  unsubscribed: C.muted,
};

const SENTIMENT_C = {
  interested: C.green,
  not_now: C.yellow,
  wrong_person: C.red,
  already_have_someone: C.yellow,
  unsubscribe: C.red,
  other: C.sub,
};

const SENTIMENT_EMOJI = {
  interested: "🔥",
  not_now: "⏳",
  wrong_person: "❌",
  already_have_someone: "⚠️",
  unsubscribe: "🚫",
  other: "💬",
};

const NICHE_ICON = { clinic: "🏥", gym: "💪", real_estate: "🏢" };
const REGION_FLAG = { UAE: "🇦🇪", Saudi: "🇸🇦", USA: "🇺🇸", UK: "🇬🇧", Europe: "🇪🇺" };

// ─── UTILS ────────────────────────────────────────────────────────────────────
function timeAgo(date) {
  if (!date) return "—";
  const diff = Date.now() - new Date(date).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1) return "just now";
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  return `${Math.floor(h / 24)}d ago`;
}

function timeUntil(date) {
  if (!date) return "—";
  const diff = new Date(date).getTime() - Date.now();
  if (diff < 0) return "overdue";
  const h = Math.floor(diff / 3600000);
  if (h < 24) return `in ${h}h`;
  return `in ${Math.floor(h / 24)}d`;
}

function scoreColor(s) {
  if (s >= 70) return C.green;
  if (s >= 50) return C.yellow;
  return C.red;
}

// ─── BASE COMPONENTS ─────────────────────────────────────────────────────────

function Card({ children, style = {}, accent }) {
  return (
    <div style={{
      background: C.card,
      border: `1px solid ${accent ? accent + "33" : C.border}`,
      borderRadius: 16,
      padding: 20,
      ...style
    }}>{children}</div>
  );
}

function SectionTitle({ children, count, color }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 16 }}>
      <span style={{ fontSize: 14, fontWeight: 700, color: C.text }}>{children}</span>
      {count !== undefined && (
        <span style={{
          fontSize: 11, fontWeight: 700,
          background: (color || C.brand) + "22",
          color: color || C.brand,
          border: `1px solid ${(color || C.brand)}44`,
          borderRadius: 999, padding: "2px 8px"
        }}>{count}</span>
      )}
    </div>
  );
}

function Pill({ label, color }) {
  return (
    <span style={{
      fontSize: 11, fontWeight: 600,
      padding: "3px 8px", borderRadius: 999,
      background: color + "1a", color,
      border: `1px solid ${color}33`,
      textTransform: "capitalize", letterSpacing: "0.03em",
      whiteSpace: "nowrap"
    }}>{label?.replace("_", " ")}</span>
  );
}

function Btn({ children, onClick, color = C.brand, variant = "solid", disabled, style = {} }) {
  const base = {
    border: "none", borderRadius: 8,
    padding: "7px 14px", fontSize: 12,
    fontWeight: 600, cursor: disabled ? "not-allowed" : "pointer",
    transition: "opacity 0.15s", opacity: disabled ? 0.5 : 1,
    ...style
  };
  if (variant === "solid") return (
    <button onClick={onClick} disabled={disabled} style={{
      ...base, background: color, color: "#fff"
    }}>{children}</button>
  );
  return (
    <button onClick={onClick} disabled={disabled} style={{
      ...base,
      background: color + "1a",
      color, border: `1px solid ${color}33`
    }}>{children}</button>
  );
}

function Select({ value, onChange, options }) {
  return (
    <select value={value} onChange={e => onChange(e.target.value)} style={{
      background: C.surface, border: `1px solid ${C.border}`,
      color: C.text, borderRadius: 8, padding: "8px 12px",
      fontSize: 13, outline: "none", cursor: "pointer"
    }}>
      {options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
    </select>
  );
}

// ─── STAT GRID ────────────────────────────────────────────────────────────────

function StatGrid({ stats }) {
  return (
    <div style={{
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(140px, 1fr))",
      gap: 10, marginBottom: 24
    }}>
      {stats.map(s => (
        <div key={s.label} style={{
          background: C.card,
          border: `1px solid ${s.color ? s.color + "33" : C.border}`,
          borderRadius: 12, padding: "14px 16px"
        }}>
          <div style={{ fontSize: 26, fontWeight: 800, color: s.color || C.text, lineHeight: 1 }}>
            {s.value}
          </div>
          <div style={{ fontSize: 12, color: C.sub, marginTop: 5 }}>{s.label}</div>
          {s.sub && <div style={{ fontSize: 10, color: C.muted, marginTop: 2 }}>{s.sub}</div>}
        </div>
      ))}
    </div>
  );
}

// ─── ACCOUNT HEALTH ───────────────────────────────────────────────────────────

function HealthBar({ label, value, limit, unit = "%" }) {
  const pct = Math.min((value / limit) * 100, 100);
  const color = pct > 80 ? C.red : pct > 50 ? C.yellow : C.green;
  return (
    <div style={{ marginBottom: 12 }}>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 5 }}>
        <span style={{ fontSize: 12, color: C.sub }}>{label}</span>
        <span style={{ fontSize: 12, fontWeight: 600, color }}>
          {value}{unit} <span style={{ color: C.muted }}>/ {limit}{unit} limit</span>
        </span>
      </div>
      <div style={{ height: 4, background: C.surface, borderRadius: 99 }}>
        <div style={{ height: 4, width: `${pct}%`, background: color, borderRadius: 99, transition: "width 0.5s" }} />
      </div>
    </div>
  );
}

function AccountHealth({ health }) {
  const isHealthy = health.bounceRate < 3 && health.spamComplaints < 1 && health.openRate > 15;
  return (
    <Card accent={isHealthy ? C.green : C.red}>
      <SectionTitle color={isHealthy ? C.green : C.red}>
        {isHealthy ? "✅ Account Health" : "⚠️ Account Health — Action Needed"}
      </SectionTitle>
      <HealthBar label="Email Bounce Rate" value={health.bounceRate} limit={5} />
      <HealthBar label="Spam Complaints / day" value={health.spamComplaints} limit={2} unit="" />
      <div style={{ marginBottom: 12 }}>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 5 }}>
          <span style={{ fontSize: 12, color: C.sub }}>Email Open Rate</span>
          <span style={{ fontSize: 12, fontWeight: 600, color: health.openRate >= 10 ? C.green : C.red }}>
            {health.openRate}% <span style={{ color: C.muted }}>/ 10% min</span>
          </span>
        </div>
        <div style={{ height: 4, background: C.surface, borderRadius: 99 }}>
          <div style={{
            height: 4,
            width: `${Math.min((health.openRate / 30) * 100, 100)}%`,
            background: health.openRate >= 10 ? C.green : C.red,
            borderRadius: 99
          }} />
        </div>
      </div>
      <div style={{ display: "flex", gap: 8, marginTop: 14 }}>
        <div style={{ flex: 1, background: C.surface, borderRadius: 8, padding: "8px 12px", textAlign: "center" }}>
          <div style={{ fontSize: 11, color: C.sub }}>WhatsApp</div>
          <div style={{ fontSize: 13, fontWeight: 700, color: health.whatsappBlocked > 0 ? C.red : C.green, marginTop: 2 }}>
            {health.whatsappBlocked > 0 ? `${health.whatsappBlocked} blocked` : "Clear"}
          </div>
        </div>
        <div style={{ flex: 1, background: C.surface, borderRadius: 8, padding: "8px 12px", textAlign: "center" }}>
          <div style={{ fontSize: 11, color: C.sub }}>Emails Today</div>
          <div style={{ fontSize: 13, fontWeight: 700, color: C.text, marginTop: 2 }}>
            {health.emailsSentToday} / {health.emailDailyLimit}
          </div>
        </div>
        <div style={{ flex: 1, background: C.surface, borderRadius: 8, padding: "8px 12px", textAlign: "center" }}>
          <div style={{ fontSize: 11, color: C.sub }}>Warm-up Week</div>
          <div style={{ fontSize: 13, fontWeight: 700, color: C.brand, marginTop: 2 }}>
            Week {health.warmupWeek}
          </div>
        </div>
      </div>
    </Card>
  );
}

// ─── REPLIES PANEL ────────────────────────────────────────────────────────────

function RepliesPanel({ prospects }) {
  const replies = prospects
    .filter(p => p.history?.some(h => h.reply))
    .sort((a, b) => {
      const aDate = Math.max(...a.history.filter(h => h.repliedAt).map(h => new Date(h.repliedAt).getTime()));
      const bDate = Math.max(...b.history.filter(h => h.repliedAt).map(h => new Date(h.repliedAt).getTime()));
      return bDate - aDate;
    })
    .slice(0, 10);

  if (replies.length === 0) return (
    <Card>
      <SectionTitle>💬 Recent Replies</SectionTitle>
      <div style={{ color: C.muted, fontSize: 13, textAlign: "center", padding: "20px 0" }}>
        No replies yet. Replies will appear here instantly.
      </div>
    </Card>
  );

  return (
    <Card>
      <SectionTitle count={replies.length}>💬 Recent Replies</SectionTitle>
      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {replies.map(p => {
          const lastReply = [...p.history].reverse().find(h => h.reply);
          if (!lastReply) return null;
          const sentiment = lastReply.replyTag || "other";
          return (
            <div key={p._id} style={{
              background: C.surface, borderRadius: 10, padding: 12,
              border: `1px solid ${SENTIMENT_C[sentiment]}22`
            }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                <div>
                  <div style={{ fontSize: 13, fontWeight: 600 }}>
                    {NICHE_ICON[p.niche]} {p.businessName}
                    <span style={{ color: C.muted, fontSize: 11, marginLeft: 8 }}>{p.city}</span>
                  </div>
                  <div style={{ fontSize: 12, color: C.dim, marginTop: 2 }}>
                    {timeAgo(lastReply.repliedAt)} via {lastReply.channel}
                  </div>
                </div>
                <Pill label={`${SENTIMENT_EMOJI[sentiment]} ${sentiment}`} color={SENTIMENT_C[sentiment]} />
              </div>
              <div style={{
                marginTop: 8, fontSize: 12, color: C.sub,
                background: C.card, borderRadius: 7, padding: "7px 10px",
                fontStyle: "italic"
              }}>
                "{lastReply.reply}"
              </div>
              {lastReply.suggestedReply && (
                <div style={{ marginTop: 6 }}>
                  <div style={{ fontSize: 10, color: C.muted, marginBottom: 3 }}>SUGGESTED REPLY</div>
                  <div style={{
                    fontSize: 12, color: "#93c5fd",
                    background: "#1e3a5f22", borderRadius: 7,
                    padding: "7px 10px", border: "1px solid #3b82f622"
                  }}>
                    {lastReply.suggestedReply}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </Card>
  );
}

// ─── FOLLOW-UPS DUE ───────────────────────────────────────────────────────────

function FollowUpsDue({ prospects }) {
  const now = Date.now();
  const due = prospects
    .filter(p =>
      p.nextFollowUpAt &&
      new Date(p.nextFollowUpAt).getTime() < now + 24 * 3600000 &&
      !["replied", "interested", "booked", "closed", "unsubscribed", "rejected"].includes(p.status)
    )
    .sort((a, b) => new Date(a.nextFollowUpAt) - new Date(b.nextFollowUpAt))
    .slice(0, 8);

  if (due.length === 0) return (
    <Card>
      <SectionTitle>⏰ Follow-ups Due</SectionTitle>
      <div style={{ color: C.muted, fontSize: 13, textAlign: "center", padding: "20px 0" }}>
        No follow-ups due in the next 24 hours.
      </div>
    </Card>
  );

  return (
    <Card accent={C.yellow}>
      <SectionTitle count={due.length} color={C.yellow}>⏰ Follow-ups Due (24h)</SectionTitle>
      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {due.map(p => (
          <div key={p._id} style={{
            display: "flex", justifyContent: "space-between", alignItems: "center",
            background: C.surface, borderRadius: 8, padding: "10px 12px"
          }}>
            <div>
              <div style={{ fontSize: 13, fontWeight: 600 }}>
                {NICHE_ICON[p.niche]} {p.businessName}
              </div>
              <div style={{ fontSize: 11, color: C.dim, marginTop: 2 }}>
                Step {p.currentStep + 1} of 4 · {REGION_FLAG[p.region]} {p.region}
              </div>
            </div>
            <div style={{ textAlign: "right" }}>
              <div style={{ fontSize: 12, fontWeight: 700, color: C.yellow }}>
                {timeUntil(p.nextFollowUpAt)}
              </div>
              <div style={{ fontSize: 10, color: C.muted, marginTop: 2 }}>
                via {p.lastChannelUsed || "whatsapp"}
              </div>
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}

// ─── HUMAN REVIEW QUEUE ───────────────────────────────────────────────────────

function ReviewQueue({ prospects, onAction }) {
  const queue = prospects.filter(p => p.humanReviewRequired &&
    ["cold", "review_queue"].includes(p.status));

  if (queue.length === 0) return null;

  async function act(id, action) {
    try {
      await fetch(`${API}/prospects/${id}/review`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action })
      });
      onAction();
    } catch (e) {
      console.error(e);
    }
  }

  return (
    <Card accent={C.yellow} style={{ marginBottom: 20 }}>
      <SectionTitle count={queue.length} color={C.yellow}>⏳ Human Review Queue — Top Prospects</SectionTitle>
      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {queue.map(p => (
          <div key={p._id} style={{
            background: C.surface, borderRadius: 10, padding: 14,
            border: `1px solid ${C.border}`
          }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 12 }}>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 14, fontWeight: 700 }}>
                  {NICHE_ICON[p.niche]} {p.businessName}
                  <span style={{ color: C.muted, fontSize: 11, marginLeft: 8, fontWeight: 400 }}>{p.city}</span>
                </div>
                <div style={{ fontSize: 12, color: C.dim, marginTop: 3 }}>
                  {REGION_FLAG[p.region]} {p.region} ·
                  Score: <span style={{ color: scoreColor(p.totalScore), fontWeight: 700 }}>{p.totalScore}</span> ·
                  {p.whatsapp ? " 📱 WhatsApp" : ""} {p.emails?.length ? " 📧 Email" : ""}
                </div>
                {p.observations?.[0] && (
                  <div style={{
                    marginTop: 8, fontSize: 12, color: "#93c5fd",
                    background: "#1e3a5f22", borderRadius: 7, padding: "7px 10px",
                    border: "1px solid #3b82f622"
                  }}>
                    📊 {p.observations[0].text}
                  </div>
                )}
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                <Btn onClick={() => act(p._id, "approved")} color={C.green} variant="outline">
                  ✓ Approve
                </Btn>
                <Btn onClick={() => act(p._id, "rejected")} color={C.red} variant="outline">
                  ✗ Reject
                </Btn>
              </div>
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}

// ─── FIND PANEL ───────────────────────────────────────────────────────────────

function FindPanel({ onStarted }) {
  const [niche, setNiche] = useState("clinic");
  const [region, setRegion] = useState("UAE");
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState(null);

  async function run() {
    setLoading(true); setMsg(null);
    try {
      const res = await fetch(`${API}/campaigns/find`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ niche, region, maxPerCity: 20 })
      });
      const data = await res.json();
      setMsg({ text: data.message || "Search started", ok: true });
      setTimeout(onStarted, 3000);
    } catch {
      setMsg({ text: "Failed to start — is the server running?", ok: false });
    }
    setLoading(false);
  }

  return (
    <Card>
      <SectionTitle>🔍 Find New Prospects</SectionTitle>
      <div style={{ display: "flex", gap: 10, flexWrap: "wrap", alignItems: "flex-end" }}>
        <div>
          <div style={{ fontSize: 11, color: C.muted, marginBottom: 5, fontWeight: 600 }}>NICHE</div>
          <Select value={niche} onChange={setNiche} options={[
            { value: "clinic", label: "🏥 Clinic" },
            { value: "gym", label: "💪 Gym" },
            { value: "real_estate", label: "🏢 Real Estate" },
          ]} />
        </div>
        <div>
          <div style={{ fontSize: 11, color: C.muted, marginBottom: 5, fontWeight: 600 }}>REGION</div>
          <Select value={region} onChange={setRegion} options={[
            { value: "UAE", label: "🇦🇪 UAE" },
            { value: "Saudi", label: "🇸🇦 Saudi" },
            { value: "USA", label: "🇺🇸 USA" },
            { value: "UK", label: "🇬🇧 UK" },
            { value: "Europe", label: "🇪🇺 Europe" },
          ]} />
        </div>
        <Btn onClick={run} disabled={loading} style={{ height: 38, padding: "0 20px" }}>
          {loading ? "Starting..." : "Run Search"}
        </Btn>
        {msg && (
          <span style={{ fontSize: 13, color: msg.ok ? C.green : C.red, fontWeight: 500 }}>
            {msg.ok ? "✓" : "✗"} {msg.text}
          </span>
        )}
      </div>
    </Card>
  );
}

// ─── PROSPECT TABLE ───────────────────────────────────────────────────────────

const ALL_STATUSES = ["all", "cold", "messaged", "replied", "interested", "booked", "closed"];

function ProspectTable({ prospects }) {
  const [statusFilter, setStatusFilter] = useState("all");
  const [nicheFilter, setNicheFilter] = useState("all");
  const [regionFilter, setRegionFilter] = useState("all");

  const filtered = prospects.filter(p => {
    if (statusFilter !== "all" && p.status !== statusFilter) return false;
    if (nicheFilter !== "all" && p.niche !== nicheFilter) return false;
    if (regionFilter !== "all" && p.region !== regionFilter) return false;
    return true;
  });

  const filterBtn = (val, curr, set, label) => (
    <button key={val} onClick={() => set(val)} style={{
      background: curr === val ? C.brand + "22" : "transparent",
      border: `1px solid ${curr === val ? C.brand : C.border}`,
      color: curr === val ? C.brand : C.dim,
      borderRadius: 7, padding: "4px 10px", fontSize: 11,
      fontWeight: 600, cursor: "pointer", textTransform: "capitalize",
      whiteSpace: "nowrap"
    }}>{label}</button>
  );

  return (
    <Card>
      <div style={{ marginBottom: 14 }}>
        <SectionTitle count={filtered.length}>📋 All Prospects</SectionTitle>
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 8 }}>
          {ALL_STATUSES.map(s => filterBtn(s, statusFilter, setStatusFilter, s))}
        </div>
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
          {["all", "clinic", "gym", "real_estate"].map(n =>
            filterBtn(n, nicheFilter, setNicheFilter, n === "all" ? "All niches" : `${NICHE_ICON[n]} ${n}`)
          )}
          {["all", "UAE", "Saudi", "USA", "UK", "Europe"].map(r =>
            filterBtn(r, regionFilter, setRegionFilter, r === "all" ? "All regions" : `${REGION_FLAG[r]} ${r}`)
          )}
        </div>
      </div>

      {filtered.length === 0 ? (
        <div style={{ color: C.muted, fontSize: 13, textAlign: "center", padding: "30px 0" }}>
          No prospects match this filter. Run a search above to find your first batch.
        </div>
      ) : (
        <div style={{ overflowX: "auto" }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
            <thead>
              <tr style={{ borderBottom: `1px solid ${C.border}` }}>
                {["Business", "", "Region", "Score", "Contact", "Status", "Step", "Last Contact", "Next Follow-up"].map(h => (
                  <th key={h} style={{
                    textAlign: "left", padding: "8px 10px",
                    color: C.muted, fontWeight: 600, fontSize: 10,
                    textTransform: "uppercase", letterSpacing: "0.06em",
                    whiteSpace: "nowrap"
                  }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map(p => (
                <tr key={p._id} style={{
                  borderBottom: `1px solid ${C.border}`,
                  transition: "background 0.1s"
                }}
                  onMouseEnter={e => e.currentTarget.style.background = C.surface}
                  onMouseLeave={e => e.currentTarget.style.background = "transparent"}
                >
                  <td style={{ padding: "10px 10px" }}>
                    <div style={{ fontWeight: 600, fontSize: 13 }}>{p.businessName}</div>
                    <div style={{ color: C.muted, fontSize: 11, marginTop: 1 }}>{p.name}</div>
                  </td>
                  <td style={{ padding: "10px 4px", fontSize: 16 }}>{NICHE_ICON[p.niche]}</td>
                  <td style={{ padding: "10px 10px", whiteSpace: "nowrap" }}>
                    {REGION_FLAG[p.region]} <span style={{ color: C.sub, fontSize: 12 }}>{p.city || p.region}</span>
                  </td>
                  <td style={{ padding: "10px 10px" }}>
                    <span style={{ color: scoreColor(p.totalScore), fontWeight: 700 }}>{p.totalScore}</span>
                  </td>
                  <td style={{ padding: "10px 10px" }}>
                    <div style={{ display: "flex", gap: 4 }}>
                      {p.whatsapp && <span title="WhatsApp" style={{ fontSize: 13 }}>📱</span>}
                      {p.emails?.length > 0 && <span title="Email" style={{ fontSize: 13 }}>📧</span>}
                      {p.linkedin && <span title="LinkedIn" style={{ fontSize: 13 }}>💼</span>}
                    </div>
                  </td>
                  <td style={{ padding: "10px 10px" }}>
                    <Pill label={p.status} color={STATUS_C[p.status] || C.muted} />
                  </td>
                  <td style={{ padding: "10px 10px", color: C.dim, fontSize: 12 }}>
                    {p.currentStep || 0} / 4
                  </td>
                  <td style={{ padding: "10px 10px", color: C.dim, fontSize: 12, whiteSpace: "nowrap" }}>
                    {timeAgo(p.lastContactedAt)}
                  </td>
                  <td style={{ padding: "10px 10px", fontSize: 12, whiteSpace: "nowrap" }}>
                    <span style={{
                      color: p.nextFollowUpAt && new Date(p.nextFollowUpAt) < new Date() ? C.red : C.dim
                    }}>
                      {timeUntil(p.nextFollowUpAt)}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </Card>
  );
}

// ─── MAIN APP ─────────────────────────────────────────────────────────────────

export default function Dashboard() {
  const [prospects, setProspects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [lastRefresh, setLastRefresh] = useState(null);
  const [tab, setTab] = useState("overview");

  async function load() {
    try {
      const res = await fetch(`${API}/prospects`);
      const data = await res.json();
      setProspects(Array.isArray(data) ? data : []);
      setLastRefresh(new Date());
    } catch {
      setProspects([]);
    }
    setLoading(false);
  }

  useEffect(() => {
    load();
    const t = setInterval(load, 30000);
    return () => clearInterval(t);
  }, []);

  // ── Pipeline stats ──
  const total = prospects.length;
  const messaged = prospects.filter(p => ["messaged","replied","interested","booked","closed"].includes(p.status)).length;
  const replied = prospects.filter(p => ["replied","interested","booked","closed"].includes(p.status)).length;
  const interested = prospects.filter(p => ["interested","booked","closed"].includes(p.status)).length;
  const booked = prospects.filter(p => ["booked","closed"].includes(p.status)).length;
  const reviewQueue = prospects.filter(p => p.humanReviewRequired && ["cold","review_queue"].includes(p.status)).length;
  const replyRate = messaged > 0 ? Math.round((replied / messaged) * 100) : 0;

  // ── Mock health data (replace with real API call when ready) ──
  const health = {
    bounceRate: 1.2,
    spamComplaints: 0,
    openRate: 22,
    whatsappBlocked: 0,
    emailsSentToday: 8,
    emailDailyLimit: 10,
    warmupWeek: 1,
  };

  const TABS = ["overview", "prospects", "replies", "health"];

  return (
    <div style={{
      minHeight: "100vh", background: C.bg, color: C.text,
      fontFamily: "ui-sans-serif, system-ui, -apple-system, sans-serif",
      fontSize: 14
    }}>

      {/* ── Header ── */}
      <div style={{
        borderBottom: `1px solid ${C.border}`,
        padding: "0 28px",
        display: "flex", alignItems: "center",
        justifyContent: "space-between",
        height: 54, position: "sticky", top: 0,
        background: C.bg, zIndex: 10
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
          <div>
            <span style={{ fontWeight: 800, fontSize: 15, letterSpacing: "-0.02em" }}>
              Outreach Tool
            </span>
            <span style={{ color: C.muted, fontSize: 12, marginLeft: 10 }}>
              mahboobgrowth.netlify.app
            </span>
          </div>
          <div style={{ display: "flex", gap: 2 }}>
            {TABS.map(t => (
              <button key={t} onClick={() => setTab(t)} style={{
                background: tab === t ? C.brand + "18" : "transparent",
                border: "none",
                color: tab === t ? C.brand : C.dim,
                borderRadius: 7, padding: "5px 12px",
                fontSize: 12, fontWeight: 600,
                cursor: "pointer", textTransform: "capitalize"
              }}>{t}</button>
            ))}
          </div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          {reviewQueue > 0 && (
            <div style={{
              background: C.yellow + "22", color: C.yellow,
              border: `1px solid ${C.yellow}44`,
              borderRadius: 999, padding: "3px 10px",
              fontSize: 11, fontWeight: 700, cursor: "pointer"
            }} onClick={() => setTab("overview")}>
              ⏳ {reviewQueue} to review
            </div>
          )}
          <span style={{ fontSize: 11, color: C.muted }}>
            {lastRefresh ? `Updated ${timeAgo(lastRefresh)}` : "Loading..."}
          </span>
          <Btn onClick={load} variant="outline" color={C.dim}>↻ Refresh</Btn>
        </div>
      </div>

      {/* ── Body ── */}
      <div style={{ padding: "24px 28px", maxWidth: 1400, margin: "0 auto" }}>

        {/* ── Pipeline Stats (always visible) ── */}
        <StatGrid stats={[
          { label: "Total Found", value: total },
          { label: "Messaged", value: messaged, color: C.brand },
          { label: "Replied", value: replied, color: C.purple },
          { label: "Interested", value: interested, color: C.green },
          { label: "Booked", value: booked, color: C.cyan },
          {
            label: "Reply Rate", value: `${replyRate}%`,
            color: replyRate >= 15 ? C.green : replyRate >= 10 ? C.yellow : C.red,
            sub: "target: 15%+"
          },
          ...(reviewQueue > 0 ? [{ label: "Review Queue", value: reviewQueue, color: C.yellow, sub: "needs approval" }] : [])
        ]} />

        {/* ── OVERVIEW TAB ── */}
        {tab === "overview" && (
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
            <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
              <FindPanel onStarted={load} />
              {reviewQueue > 0 && <ReviewQueue prospects={prospects} onAction={load} />}
              <FollowUpsDue prospects={prospects} />
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
              <RepliesPanel prospects={prospects} />
              <AccountHealth health={health} />
            </div>
          </div>
        )}

        {/* ── PROSPECTS TAB ── */}
        {tab === "prospects" && (
          <div>
            <div style={{ marginBottom: 20 }}>
              <FindPanel onStarted={load} />
            </div>
            {reviewQueue > 0 && <ReviewQueue prospects={prospects} onAction={load} />}
            <ProspectTable prospects={prospects} />
          </div>
        )}

        {/* ── REPLIES TAB ── */}
        {tab === "replies" && (
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
            <RepliesPanel prospects={prospects} />
            <FollowUpsDue prospects={prospects} />
          </div>
        )}

        {/* ── HEALTH TAB ── */}
        {tab === "health" && (
          <div style={{ maxWidth: 600 }}>
            <AccountHealth health={health} />
          </div>
        )}

      </div>
    </div>
  );
}
