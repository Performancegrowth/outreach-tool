const axios = require('axios');
const Prospect = require('../models/Prospect');
const { buildObservation } = require('../services/personalization');
const { scheduleFollowups } = require('../workers/followupWorker');
const { checkWhatsAppExists, normalizeNumber } = require('../services/sender/whatsapp');

const APIFY_BASE = 'https://api.apify.com/v2';
const TOKEN = process.env.APIFY_API_TOKEN;

// ─── SEARCH CONFIGS PER NICHE ─────────────────────────────────────────────────

const NICHE_QUERIES = {
  clinic: ['dental clinic', 'medical clinic', 'wellness center', 'doctor clinic', 'health clinic'],
  gym: ['gym', 'fitness studio', 'personal trainer', 'fitness center', 'CrossFit'],
  real_estate: ['real estate agency', 'property broker', 'real estate developer', 'property agency']
};

const REGION_CITIES = {
  UAE: ['Dubai', 'Abu Dhabi', 'Sharjah', 'Ajman'],
  Saudi: ['Riyadh', 'Jeddah', 'Dammam', 'Mecca'],
  USA: ['New York', 'Los Angeles', 'Chicago', 'Houston', 'Miami'],
  UK: ['London', 'Manchester', 'Birmingham', 'Leeds'],
  Europe: ['Berlin', 'Madrid', 'Paris', 'Barcelona', 'Amsterdam']
};

// ─── RUN APIFY GOOGLE MAPS SCRAPER ───────────────────────────────────────────

async function scrapeGoogleMaps(query, city, maxResults = 20) {
  try {
    // Start the actor run
    const runRes = await axios.post(
      `${APIFY_BASE}/acts/compass~crawler-google-places/runs?token=${TOKEN}`,
      {
        searchStringsArray: [`${query} in ${city}`],
        maxCrawledPlacesPerSearch: maxResults,
        language: 'en',
        includeReviews: true,
        maxReviews: 50,
        reviewsSort: 'newest'
      }
    );

    const runId = runRes.data.data.id;
    console.log(`[Finder] Google Maps run started: ${runId} — "${query} in ${city}"`);

    // Wait for run to finish (poll every 5 seconds)
    const results = await waitForRun(runId);
    return results;

  } catch (err) {
    console.error(`[Finder] Google Maps scrape failed: ${err.message}`);
    return [];
  }
}

// ─── WAIT FOR APIFY RUN TO COMPLETE ──────────────────────────────────────────

async function waitForRun(runId, maxWaitMs = 120000) {
  const start = Date.now();

  while (Date.now() - start < maxWaitMs) {
    await sleep(5000);

    const statusRes = await axios.get(
      `${APIFY_BASE}/actor-runs/${runId}?token=${TOKEN}`
    );

    const status = statusRes.data.data.status;

    if (status === 'SUCCEEDED') {
      // Fetch results from dataset
      const datasetId = statusRes.data.data.defaultDatasetId;
      const dataRes = await axios.get(
        `${APIFY_BASE}/datasets/${datasetId}/items?token=${TOKEN}&clean=true`
      );
      return dataRes.data;
    }

    if (['FAILED', 'ABORTED', 'TIMED-OUT'].includes(status)) {
      console.error(`[Finder] Run ${runId} ended with status: ${status}`);
      return [];
    }

    console.log(`[Finder] Run ${runId} status: ${status} — waiting...`);
  }

  console.error(`[Finder] Run ${runId} timed out`);
  return [];
}

// ─── EXTRACT OWNER NAME ───────────────────────────────────────────────────────

function extractOwnerName(place) {
  // Try to get owner name from Google Q&A, description, or website
  if (place.ownerName) return place.ownerName;
  if (place.additionalInfo?.['Owner']?.[0]) return place.additionalInfo['Owner'][0];
  // Fallback to business name
  return place.title || 'there';
}

// ─── ANALYZE REVIEWS FOR TREND ───────────────────────────────────────────────

function analyzeReviews(reviews) {
  if (!reviews || reviews.length === 0) return null;

  const currentYear = new Date().getFullYear();
  const previousYear = currentYear - 1;

  const currentYearReviews = reviews.filter(r => {
    const year = new Date(r.publishedAtDate || r.publishAt || 0).getFullYear();
    return year === currentYear;
  });

  const previousYearReviews = reviews.filter(r => {
    const year = new Date(r.publishedAtDate || r.publishAt || 0).getFullYear();
    return year === previousYear;
  });

  return {
    currentYearCount: currentYearReviews.length,
    previousYearCount: previousYearReviews.length,
    currentYear,
    previousYear,
    totalCount: reviews.length
  };
}

// ─── SCORE PROSPECT ───────────────────────────────────────────────────────────

function scoreProspect(place, reviewAnalysis) {
  let fitScore = 70;       // passed niche filter = good fit
  let engagementScore = 0;
  let contactabilityScore = 0;
  let valueScore = 0;

  // Engagement — review drop is the main signal
  if (reviewAnalysis) {
    const { previousYearCount, currentYearCount } = reviewAnalysis;
    if (previousYearCount > 0 && currentYearCount < previousYearCount) {
      const dropPct = ((previousYearCount - currentYearCount) / previousYearCount) * 100;
      if (dropPct >= 70) engagementScore = 100;
      else if (dropPct >= 50) engagementScore = 80;
      else if (dropPct >= 30) engagementScore = 60;
      else engagementScore = 30;
    }
    // Had reviews before but almost none now
    if (previousYearCount >= 10 && currentYearCount <= 5) engagementScore = Math.max(engagementScore, 90);
  }

  // Contactability
  if (place.phone) contactabilityScore += 50;
  if (place.website) contactabilityScore += 20;
  if (place.url) contactabilityScore += 10;
  contactabilityScore = Math.min(contactabilityScore, 100);

  // Value — use review count and rating as size proxy
  if (place.totalScore >= 4.0) valueScore += 40;
  if (place.reviewsCount >= 50) valueScore += 30;
  if (place.reviewsCount >= 100) valueScore += 30;
  valueScore = Math.min(valueScore, 100);

  return { fitScore, engagementScore, contactabilityScore, valueScore };
}

// ─── DEDUPLICATION CHECK ──────────────────────────────────────────────────────

async function isDuplicate(phone, email, businessName, city) {
  const normalizedPhone = phone ? normalizeNumber(phone) : null;
  const normalizedEmail = email ? email.toLowerCase().trim() : null;

  const query = { $or: [] };
  if (normalizedPhone) query.$or.push({ normalizedPhone });
  if (normalizedEmail) query.$or.push({ normalizedEmail });
  if (businessName && city) {
    query.$or.push({
      businessName: new RegExp(businessName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i'),
      city: new RegExp(city, 'i')
    });
  }

  if (query.$or.length === 0) return false;

  const existing = await Prospect.findOne(query);
  return !!existing;
}

// ─── DETERMINE REGION FROM CITY ───────────────────────────────────────────────

function getRegion(city) {
  for (const [region, cities] of Object.entries(REGION_CITIES)) {
    if (cities.some(c => city.toLowerCase().includes(c.toLowerCase()))) {
      return region;
    }
  }
  return 'USA'; // default
}

// ─── MAIN FINDER FUNCTION ─────────────────────────────────────────────────────

async function findProspects({ niche, region, maxPerCity = 20 }) {
  const queries = NICHE_QUERIES[niche];
  const cities = REGION_CITIES[region];

  if (!queries || !cities) {
    throw new Error(`Invalid niche "${niche}" or region "${region}"`);
  }

  console.log(`[Finder] Starting search: ${niche} in ${region} (${cities.length} cities)`);

  const found = [];
  const skipped = { duplicate: 0, noContact: 0, lowScore: 0 };

  for (const city of cities) {
    for (const query of queries.slice(0, 2)) { // limit to 2 queries per city to save Apify credits
      const places = await scrapeGoogleMaps(query, city, maxPerCity);
      console.log(`[Finder] Found ${places.length} places for "${query}" in ${city}`);

      for (const place of places) {
        try {
          // Skip if no contact info
          if (!place.phone && !place.website) {
            skipped.noContact++;
            continue;
          }

          // Check duplicate
          const dup = await isDuplicate(place.phone, null, place.title, city);
          if (dup) {
            skipped.duplicate++;
            continue;
          }

          // Analyze reviews
          const reviewAnalysis = analyzeReviews(place.reviews || []);

          // Score
          const { fitScore, engagementScore, contactabilityScore, valueScore } = scoreProspect(place, reviewAnalysis);
          const totalScore = Math.round(
            (fitScore * 0.30) + (engagementScore * 0.30) +
            (contactabilityScore * 0.20) + (valueScore * 0.20)
          );

          // Discard low scores
          if (totalScore < 40) {
            skipped.lowScore++;
            continue;
          }

          // Build observation
          const scrapedData = { reviews: reviewAnalysis };
          const observation = buildObservation(scrapedData);

          // Check WhatsApp
          const hasWhatsApp = place.phone ? await checkWhatsAppExists(place.phone) : false;

          // Build prospect object
          const prospectData = {
            name: extractOwnerName(place),
            businessName: place.title,
            niche,
            region: getRegion(city),
            city,
            whatsapp: hasWhatsApp ? place.phone : null,
            emails: [],
            website: place.website || null,
            googlePlaceId: place.placeId || null,
            observations: [{ ...observation, scrapedAt: new Date() }],
            fitScore,
            engagementScore,
            contactabilityScore,
            valueScore,
            normalizedPhone: place.phone ? normalizeNumber(place.phone) : null,
            sources: ['google_maps'],
            scrapedData: { reviews: reviewAnalysis }
          };

          // Save to DB
          const prospect = new Prospect(prospectData);
          await prospect.save();

          // Schedule follow-ups (unless needs human review)
          if (!prospect.humanReviewRequired) {
            await scheduleFollowups(prospect._id.toString());
          }

          found.push(prospect);
          console.log(`[Finder] ✓ Saved: ${place.title} (${city}) — score: ${totalScore}`);

        } catch (err) {
          console.error(`[Finder] Error processing place: ${err.message}`);
        }
      }

      // Pause between queries to be safe
      await sleep(3000);
    }
  }

  console.log(`[Finder] Done. Found: ${found.length} | Skipped — duplicate: ${skipped.duplicate}, no contact: ${skipped.noContact}, low score: ${skipped.lowScore}`);
  return { found: found.length, skipped };
}

// ─── HELPER ───────────────────────────────────────────────────────────────────

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

module.exports = { findProspects };
