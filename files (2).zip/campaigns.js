const express = require('express');
const router = express.Router();
const { findProspects } = require('../services/prospectFinder');

// POST start a new prospecting run
// Body: { niche: 'clinic'|'gym'|'real_estate', region: 'UAE'|'Saudi'|'USA'|'UK'|'Europe', maxPerCity: 20 }
router.post('/find', async (req, res) => {
  try {
    const { niche, region, maxPerCity = 20 } = req.body;

    if (!niche || !region) {
      return res.status(400).json({ error: 'niche and region are required' });
    }

    // Run in background — don't wait for it to finish
    res.json({ message: `Prospecting started for ${niche} in ${region}` });

    // Fire and forget
    findProspects({ niche, region, maxPerCity })
      .then(result => console.log(`[Campaign] Finished: ${JSON.stringify(result)}`))
      .catch(err => console.error(`[Campaign] Error: ${err.message}`));

  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
