const express = require('express');
const router = express.Router();
const Prospect = require('../models/Prospect');
const { scheduleFollowups } = require('../workers/followupWorker');
const { handleReply } = require('../services/replyHandler');

// GET all prospects with filters
router.get('/', async (req, res) => {
  try {
    const { status, niche, region, score } = req.query;
    const filter = {};
    if (status) filter.status = status;
    if (niche) filter.niche = niche;
    if (region) filter.region = region;
    if (score) filter.totalScore = { $gte: parseInt(score) };

    const prospects = await Prospect.find(filter).sort({ totalScore: -1, createdAt: -1 });
    res.json(prospects);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET single prospect
router.get('/:id', async (req, res) => {
  try {
    const prospect = await Prospect.findById(req.params.id);
    if (!prospect) return res.status(404).json({ error: 'Not found' });
    res.json(prospect);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST add prospect manually + schedule follow-ups
router.post('/', async (req, res) => {
  try {
    const prospect = new Prospect(req.body);
    await prospect.save();
    await scheduleFollowups(prospect._id.toString());
    res.status(201).json(prospect);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// PATCH update status (approve/reject from human review queue)
router.patch('/:id/review', async (req, res) => {
  try {
    const { action } = req.body; // 'approved' | 'edited' | 'rejected'
    const prospect = await Prospect.findById(req.params.id);
    if (!prospect) return res.status(404).json({ error: 'Not found' });

    prospect.humanReviewedAt = new Date();
    prospect.humanReviewAction = action;

    if (action === 'rejected') {
      prospect.status = 'rejected';
      prospect.followUpsPaused = true;
    } else {
      prospect.status = 'cold'; // will be updated to 'messaged' by worker
    }

    await prospect.save();
    res.json(prospect);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST handle incoming reply (called by webhook)
router.post('/:id/reply', async (req, res) => {
  try {
    const { replyText, channel } = req.body;
    const result = await handleReply(req.params.id, replyText, channel);
    res.json({ success: true, ...result });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET pipeline stats for dashboard
router.get('/stats/pipeline', async (req, res) => {
  try {
    const stats = await Prospect.aggregate([
      { $group: { _id: '$status', count: { $sum: 1 } } }
    ]);
    res.json(stats);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
