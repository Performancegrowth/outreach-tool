const Prospect = require('../models/Prospect');
const { sendWhatsApp, isOptOut } = require('./sender/whatsapp');
const { cancelFollowups } = require('../workers/followupWorker');
const Groq = require('groq-sdk');

const groq = new Groq({ apiKey: process.env.GROQ_API_KEY });

// ─── TAG REPLY SENTIMENT ──────────────────────────────────────────────────────

async function tagSentiment(replyText, language) {
  const prompt = language === 'ar'
    ? `صنّف هذا الرد إلى إحدى الفئات: interested / not_now / wrong_person / already_have_someone / unsubscribe / other. أرجع كلمة واحدة فقط.\nالرد: "${replyText}"`
    : `Classify this reply into one of: interested / not_now / wrong_person / already_have_someone / unsubscribe / other. Return one word only.\nReply: "${replyText}"`;

  try {
    const completion = await groq.chat.completions.create({
      model: 'llama3-8b-8192',
      messages: [{ role: 'user', content: prompt }],
      max_tokens: 10,
      temperature: 0
    });
    const tag = completion.choices[0].message.content.trim().toLowerCase();
    const valid = ['interested', 'not_now', 'wrong_person', 'already_have_someone', 'unsubscribe', 'other'];
    return valid.includes(tag) ? tag : 'other';
  } catch {
    return 'other';
  }
}

// ─── SUGGEST YOUR REPLY ───────────────────────────────────────────────────────

async function suggestReply(prospect, replyText, sentiment, language) {
  const context = `Business: ${prospect.businessName}, Niche: ${prospect.niche}, Their reply: "${replyText}", Sentiment: ${sentiment}`;

  const prompt = language === 'ar'
    ? `اقترح رد قصير وطبيعي باللغة العربية على هذا الرد من عميل محتمل. لا تكن رسمياً جداً.\n${context}`
    : `Suggest a short, natural reply in English to this prospect's message. Keep it conversational.\n${context}`;

  try {
    const completion = await groq.chat.completions.create({
      model: 'llama3-8b-8192',
      messages: [{ role: 'user', content: prompt }],
      max_tokens: 150,
      temperature: 0.7
    });
    return completion.choices[0].message.content.trim();
  } catch {
    return null;
  }
}

// ─── ALERT YOU ON WHATSAPP ────────────────────────────────────────────────────

async function alertYou(prospect, replyText, sentiment, suggestedReply) {
  const emoji = {
    interested: '🔥',
    not_now: '⏳',
    wrong_person: '❌',
    already_have_someone: '⚠️',
    unsubscribe: '🚫',
    other: '💬'
  }[sentiment] || '💬';

  const alert = [
    `${emoji} NEW REPLY`,
    `Business: ${prospect.businessName}`,
    `Niche: ${prospect.niche} | Region: ${prospect.region}`,
    `Their reply: "${replyText}"`,
    `Tag: ${sentiment}`,
    suggestedReply ? `\nSuggested reply:\n"${suggestedReply}"` : ''
  ].filter(Boolean).join('\n');

  await sendWhatsApp(process.env.YOUR_WHATSAPP_NUMBER, alert, 'alert');
}

// ─── MAIN REPLY HANDLER ───────────────────────────────────────────────────────

async function handleReply(prospectId, replyText, channel) {
  const prospect = await Prospect.findById(prospectId);
  if (!prospect) return;

  // Check for opt-out
  if (isOptOut(replyText)) {
    prospect.status = 'unsubscribed';
    prospect.followUpsPaused = true;
    await prospect.save();
    await cancelFollowups(prospectId);
    console.log(`[Reply] Prospect unsubscribed: ${prospectId}`);
    return;
  }

  // Tag sentiment
  const sentiment = await tagSentiment(replyText, prospect.language);

  // Suggest reply
  const suggested = await suggestReply(prospect, replyText, sentiment, prospect.language);

  // Update prospect record
  const lastMessage = prospect.history[prospect.history.length - 1];
  if (lastMessage) {
    lastMessage.reply = replyText;
    lastMessage.repliedAt = new Date();
    lastMessage.replyTag = sentiment;
  }

  prospect.status = sentiment === 'interested' ? 'interested' : 'replied';
  prospect.followUpsPaused = true;
  await prospect.save();

  // Cancel remaining follow-ups
  await cancelFollowups(prospectId);

  // Alert you immediately
  await alertYou(prospect, replyText, sentiment, suggested);

  console.log(`[Reply] Handled for ${prospect.businessName} — ${sentiment}`);
  return { sentiment, suggestedReply: suggested };
}

module.exports = { handleReply, tagSentiment, suggestReply };
