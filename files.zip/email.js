const axios = require('axios');

const BREVO_API = 'https://api.brevo.com/v3/smtp/email';

// ─── WARM-UP SCHEDULE ─────────────────────────────────────────────────────────
// Week 1: max 10/day | Week 2: max 30/day | Week 3+: max 100/day

function getDailyLimit(accountAgeDays) {
  if (accountAgeDays <= 7) return 10;
  if (accountAgeDays <= 14) return 30;
  if (accountAgeDays <= 21) return 60;
  return 100;
}

// ─── SEND EMAIL ───────────────────────────────────────────────────────────────

async function sendEmail({ to, subject, body, senderEmail, prospectId }) {
  try {
    const senderName = 'Mojtaba | Mahboob Growth';

    const response = await axios.post(
      BREVO_API,
      {
        sender: { name: senderName, email: senderEmail },
        to: [{ email: to }],
        subject,
        textContent: body + getUnsubscribeFooter(senderEmail)
      },
      {
        headers: {
          'api-key': process.env.BREVO_API_KEY,
          'Content-Type': 'application/json'
        }
      }
    );

    console.log(`[Email] Sent to ${to} | Prospect: ${prospectId}`);
    return { success: true, messageId: response.data.messageId, channel: 'email' };

  } catch (err) {
    const status = err.response?.status;
    const msg = err.response?.data?.message || err.message;
    console.error(`[Email] Failed for ${to}: ${status} — ${msg}`);
    return { success: false, error: msg, channel: 'email' };
  }
}

// ─── UNSUBSCRIBE FOOTER ───────────────────────────────────────────────────────

function getUnsubscribeFooter(senderEmail) {
  return `\n\n---\nTo stop receiving messages, reply with "STOP" or email ${senderEmail} with subject "Unsubscribe".`;
}

// ─── EMAIL SUBJECT LINES BY NICHE + LANGUAGE ─────────────────────────────────

function getSubject(niche, language, step) {
  const subjects = {
    clinic: {
      ar: {
        1: 'ملاحظة سريعة عن عيادتك',
        2: 'كيف العيادات الناجحة تستعيد مرضاها',
        3: 'تجربة 7 أيام — أداء فقط',
        4: 'آخر رسالة مني'
      },
      en: {
        1: 'Quick note about your clinic',
        2: 'How top clinics reactivate old patients',
        3: '7-day pilot — performance only',
        4: 'Last message from me'
      }
    },
    gym: {
      ar: {
        1: 'ملاحظة عن نادي الجيم',
        2: 'كيف الأندية تستعيد الأعضاء الصامتين',
        3: 'تجربة قصيرة — أداء فقط',
        4: 'آخر رسالة'
      },
      en: {
        1: 'Quick note about your gym',
        2: 'How top gyms recover silent members',
        3: 'Short pilot — performance only',
        4: 'Last message from me'
      }
    },
    real_estate: {
      ar: {
        1: 'ملاحظة عن الليدات القديمة',
        2: 'الاستفسارات القديمة — فرصة ضائعة',
        3: 'تجربة إعادة تفعيل — أداء فقط',
        4: 'آخر رسالة'
      },
      en: {
        1: 'Quick note about your old leads',
        2: 'Old inquiries — missed opportunity',
        3: 'Reactivation pilot — performance only',
        4: 'Last message from me'
      }
    }
  };

  return subjects[niche]?.[language]?.[step] || 'Quick note about your business';
}

module.exports = { sendEmail, getDailyLimit, getSubject };
