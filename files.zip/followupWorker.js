const { Queue, Worker, QueueScheduler } = require('bullmq');
const mongoose = require('mongoose');
const Prospect = require('../models/Prospect');
const { sendWhatsApp, checkWhatsAppExists, isOptOut } = require('../services/sender/whatsapp');
const { sendEmail, getSubject } = require('../services/sender/email');
const { generateMessages } = require('../services/personalization');

// ─── REDIS CONNECTION ─────────────────────────────────────────────────────────

const connection = {
  url: process.env.UPSTASH_REDIS_URL
};

// ─── FOLLOW-UP DELAYS ─────────────────────────────────────────────────────────
// Step 1: immediate | Step 2: Day 3 | Step 3: Day 7 | Step 4: Day 14

const STEP_DELAYS_MS = {
  1: 0,
  2: 3 * 24 * 60 * 60 * 1000,
  3: 7 * 24 * 60 * 60 * 1000,
  4: 14 * 24 * 60 * 60 * 1000
};

// ─── QUEUES ───────────────────────────────────────────────────────────────────

const followupQueue = new Queue('followups', { connection });
const scheduler = new QueueScheduler('followups', { connection });

// ─── SCHEDULE ALL FOLLOW-UPS FOR A PROSPECT ──────────────────────────────────

async function scheduleFollowups(prospectId) {
  // Schedule steps 1–4
  for (const step of [1, 2, 3, 4]) {
    await followupQueue.add(
      'send-step',
      { prospectId, step },
      {
        delay: STEP_DELAYS_MS[step],
        jobId: `${prospectId}-step-${step}`,   // prevents duplicates
        attempts: 3,
        backoff: { type: 'exponential', delay: 5000 }
      }
    );
  }
  console.log(`[Scheduler] Follow-ups scheduled for prospect: ${prospectId}`);
}

// ─── CANCEL REMAINING FOLLOW-UPS (when prospect replies) ─────────────────────

async function cancelFollowups(prospectId) {
  for (const step of [2, 3, 4]) {
    const jobId = `${prospectId}-step-${step}`;
    const job = await followupQueue.getJob(jobId);
    if (job) await job.remove();
  }
  console.log(`[Scheduler] Follow-ups cancelled for prospect: ${prospectId}`);
}

// ─── WORKER — PROCESSES EACH STEP ────────────────────────────────────────────

const worker = new Worker('followups', async (job) => {
  const { prospectId, step } = job.data;

  await mongoose.connect(process.env.MONGODB_URI);
  const prospect = await Prospect.findById(prospectId);

  if (!prospect) {
    console.warn(`[Worker] Prospect not found: ${prospectId}`);
    return;
  }

  // Skip if already replied, unsubscribed, or paused
  if (['replied', 'interested', 'booked', 'closed', 'unsubscribed', 'rejected'].includes(prospect.status)) {
    console.log(`[Worker] Skipping step ${step} for ${prospectId} — status: ${prospect.status}`);
    return;
  }

  if (prospect.followUpsPaused) {
    console.log(`[Worker] Follow-ups paused for ${prospectId}`);
    return;
  }

  // Generate messages if not already generated
  const messages = prospect.generatedMessages || await generateMessages(prospect, prospect.scrapedData);

  const messageText = messages.messages[`msg${step}`];
  if (!messageText) {
    console.error(`[Worker] No message for step ${step}`);
    return;
  }

  // ── CHANNEL SELECTION ──
  // WhatsApp → Email → LinkedIn. Never same channel twice in a row.
  let channel = null;
  let result = null;

  const lastChannel = prospect.lastChannelUsed;

  if (prospect.whatsapp && lastChannel !== 'whatsapp') {
    const exists = await checkWhatsAppExists(prospect.whatsapp);
    if (exists) {
      result = await sendWhatsApp(prospect.whatsapp, messageText, prospectId);
      channel = 'whatsapp';
    }
  }

  if (!result?.success && prospect.emails?.length && lastChannel !== 'email') {
    const subject = getSubject(prospect.niche, prospect.language, step);
    result = await sendEmail({
      to: prospect.emails[0],
      subject,
      body: messageText,
      senderEmail: prospect.senderEmail,
      prospectId
    });
    channel = 'email';
  }

  if (!result?.success) {
    console.error(`[Worker] All channels failed for ${prospectId} step ${step}`);
    return;
  }

  // ── UPDATE PROSPECT RECORD ──
  prospect.history.push({
    channel,
    step,
    message: messageText,
    sentAt: new Date(),
    delivered: result.success
  });

  prospect.currentStep = step;
  prospect.lastContactedAt = new Date();
  prospect.lastChannelUsed = channel;
  if (prospect.status === 'cold') prospect.status = 'messaged';

  if (step < 4) {
    prospect.nextFollowUpAt = new Date(Date.now() + STEP_DELAYS_MS[step + 1] - STEP_DELAYS_MS[step]);
  }

  await prospect.save();
  console.log(`[Worker] Step ${step} sent via ${channel} to ${prospect.businessName}`);

}, { connection });

// ─── WORKER ERROR HANDLING ────────────────────────────────────────────────────

worker.on('failed', (job, err) => {
  console.error(`[Worker] Job failed: ${job?.id} — ${err.message}`);
});

worker.on('completed', (job) => {
  console.log(`[Worker] Job completed: ${job.id}`);
});

module.exports = { scheduleFollowups, cancelFollowups, followupQueue };
